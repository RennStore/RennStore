#include <string>
#include "corefunc.h"
#define byte uin8_t
#define BYTE uint8_t

//Account Start From
int MULAI_DARI;
//Gmail Start From
int START_DARI = 1;
