// CPPBot.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
#include <fstream>
#include <future>
#include <thread>
#include <chrono>
#include "corefunc.h"
#include "userfunc.h"
#include <string>
#include <unistd.h>
#include <stdint.h>
//#include "json.hpp"
#include <stdio.h>
#include <curl/curl.h>
//#include <curses.h>
//#include <conio.h>
//#include <windows.h>

string key;
string key0 = "RBIX";
//string vers = "3.7
//string botps;

int portan1;
//int portan = 17252;
//string portan2 = "auto";
//string portan1 ="";





//using json = nlohmann::json;
using namespace std;
vector<GrowtopiaBot> bots;


GrowtopiaBot bot1 = {"", "", "", -1};
void BroadCastGoWorld(string name) {
	bot1.gotow(name);
}
void BroadCastPacket(int typ, string text) {
	bot1.packetPeer(typ, text);
}
string getBotPos() {
	string datas = "";
	if (bot1.getPeer()) datas += "BOT 1: x:" + to_string(bot1.localX) + " y: " + to_string(bot1.localY) + "\n";
	return datas;
}
void input() {
	int c = 0;
	while (1) {
		string data;
		getline(cin, data);
		if (data == "/bot") {
			if (bot1.getPeer()) cout << bot1.uname << " At " << bot1.world->name << endl;
			
		}
		else if (data.find("/say ") != std::string::npos) BroadCastPacket(2, "action|input\n|text|" + data.substr(5));
		else if (data == "/status") {
			string status = "";
			if (bot1.getPeer()); status += "BOT 1: ON\n";
			cout << status << endl;
		}
		else if (data=="/pos") getBotPos();
		else if (data=="/help") cout << "Console Command: /clear, go <name>, /status, /bot (print bot world), /say <text>,/pos" << endl;
		else if (data.find("/go ") != std::string::npos) {
			string wr = data.substr(4);
			BroadCastGoWorld(wr);
			cout << "Going to: " << wr << endl;
		}
		else if (data=="/clear") system("clear");
	}
}

GrowtopiaBot makeBot(string user, string pass, string host, int port, string vers, string wname) {
	GrowtopiaBot bot = {user, pass, host, port};
	bot.gameVersion = vers;
	bot.currentWorld = wname;
	bot.userInit();
	bots.push_back(bot);
	return bot;
}

void botSetup(){
	string user1 = grwid;
	string pass1 = pss;
	string vers = gtvrs;
	string wn = homes;
	bot1 = makeBot(user1, pass1,"213.179.209.168", portan1, vers, wn);
	


	while(true) {
		bot1.eventLoop();
		
	}
//void botSetup() {
//	ifstream i("config.json");
//	json j;
//	i >> j;
//	init();
//	system("clear");
//	string user1 = j["bot1"].get<string>(), pass1 = j["pass1"].get<string>();
//string vers = j["gtversion"].get<string>();
//	string wn = j["home"].get<string>();
//	bot1 = makeBot(user1, pass1,"213.179.209.168", 17198, vers, wn);
//	while (true) {
//		bot1.eventLoop();
//	}
} 




void create(){
system("clear");
cout << "Success Login, Lets Create Some Growid!\n";
cout << "Input Port : ";
cin >> portan1;
cout << "Input Growid : ";
cin >> Growid0;
cout << "Input Password : ";
cin >> Passw0;
cout << "Input Random Email\n(No Need  @gmail.com) : ";
cin >> Email0;
cout <<"Input Start Number : ";
cin >> MULAI_DARI;
//cout <<"Angka Random Email";
//cin >> START_DARI;
system("clear");
cout << "Creating Growid, Please Wait...\nAfter done Check acc.txt\n";
	std::thread thr(input);
	thr.detach();
	botSetup();

}

void keylogin(){
cout << "Input Key for Login: ";
cin >> key;
if (key == key0) {
    cout << "Login Key Success\n";
    create();
}
else {
     cout << "Login Key Failed!Please Try Again\n";
keylogin();
}
}




int main() {

        
//https://pastebin.com/7bq5XaK9

	
system("clear");
std::cout << R"(
  _____     _        __  __           _     
 |  ___|_ _| | _____|  \/  | ___   __| |____
 | |_ / _` | |/ / _ \ |\/| |/ _ \ / _` |_  /
 |  _| (_| |   <  __/ |  | | (_) | (_| |/ / 
 |_|  \__,_|_|\_\___|_|  |_|\___/ \__,_/___|
                                                         
           )" << '\n';

	
cout << "Welcome To VIP Create ID Script\n";
cout << "Source from : Github!\n";
cout << "Re-Edit By : Fakemodz\n";
cout << "Version : 3.77\n";
cout << "Do Not Trust RESELLER!!!\n" << endl;
keylogin();			

//sleep(3);
//main(); 
  
}




